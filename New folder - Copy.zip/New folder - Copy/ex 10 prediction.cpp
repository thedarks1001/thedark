#include <stdio.h>

int main() {
    int a = 2, b = 3, c;
    float x = 5.0, y;

    // 1
    y = a * b;
    printf("y = a * b = %.2f\n", y);

    // 2
    c = a * b;
    printf("c = a * b = %d\n", c);

    // 3
    y = a / b;  // integer division first, then cast to float
    printf("y = a / b = %.2f\n", y);

    // 4
    c = a / b;
    printf("c = a / b = %d\n", c);

    // 5
    y = a / b * x;
    printf("y = a / b * x = %.2f\n", y);

    // 6
    c = a / b * x;
    printf("c = a / b * x = %d\n", c);

    // 7
    y = a * x / b;
    printf("y = a * x / b = %.2f\n", y);

    // 8
    c = a * x / b;
    printf("c = a * x / b = %d\n", c);

    return 0;
}
