#include <stdio.h>

int main() {
    int a, b, c, max;
    printf("Enter three integers: ");
    scanf("%d %d %d", &a, &b, &c);

    max = a;
    if (b > max) max = b;
    if (c > max) max = c;

    printf("Maximum = %d\n", max);
    return 0;
    /* khong dung bien tam 
	#include <stdio.h> 

int main() {
    int a, b, c, max;
    printf("Enter three integers: ");
    scanf("%d %d %d", &a, &b, &c);

    if (a > b) {
        if (a > c) max = a;
        else max = c;
    } else {
        if (b > c) max = b;
        else max = c;
    }

    printf("Maximum = %d\n", max);
    return 0;
}
*/
}
