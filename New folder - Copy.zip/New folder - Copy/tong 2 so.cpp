#include <stdio.h>

int main() {
    int a, b;
    printf("Nhap so thu nhat: ");
    scanf("%d", &a);
    printf("Nhap so thu hai: ");
    scanf("%d", &b);

    printf("Ban da nhap: %d va %d\n", a, b);
    printf("Tong cua hai so = %d\n", a + b);

    return 0;
}
