#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  
  int n;
  printf("Nhap chieu cao tam giac: ");
  scanf("%d", &n);

  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:

  // vong lap tung hang
  for (int i = 1; i <= n; i++) {

    // in khoang trang ben trai
    for (int j = 1; j <= n - i; j++) {
      printf(" ");
    }

    // in dau * hoac khoang trong ben trong
    for (int j = 1; j <= 2 * i - 1; j++) {
      // hang cuoi hoac vien ben trai, ben phai thi in *
      if (i == n || j == 1 || j == 2 * i - 1)
        printf("*");
      else
        printf(" ");
    }

    // xuong dong sau moi hang
    printf("\n");
  }

  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system("pause");
  return(0);
}
