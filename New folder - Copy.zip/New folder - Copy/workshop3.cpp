#include <stdio.h>
#define MAX_SIZE 100

// Function prototypes
void inputArray(int arr[], int *size);
void displayArray(int arr[], int size);
int searchValue(int arr[], int size, int target);
void calculateStatistics(int arr[], int size);

int main() {
	int arr[MAX_SIZE], size = 0, target, index, choice;

	// Menu Loop
	do {
		// Display the menu
		printf("\n--- Menu ---\n");
		printf("1. Input data\n");
		printf("2. Display array\n");
		printf("3. Search for a number\n");
		printf("4. Calculate statistics (Sum, Average, Max, Min)\n");
		printf("5. Exit\n");
		printf("Enter your choice: ");
		scanf("%d", &choice);

		switch(choice) {
			case 1: // Input data
				inputArray(arr, &size);
				break;
			case 2: // Display array
				if (size > 0) {
					displayArray(arr, size);
				} else {
					printf("No data to display. Please input data first.\n");
				}
				break;
			case 3: // Search value
				if (size > 0) {
					printf("Enter the number to search: ");
					scanf("%d", &target);
					index = searchValue(arr, size, target);
					if (index != -1) {
						printf("Value %d found at index %d.\n", target, index);
					} else {
						printf("Value %d not found in the array.\n", target);
					}
				} else {
					printf("No data available. Please input data first.\n");
				}
				break;
			case 4: // Statistics
				if (size > 0) {
					calculateStatistics(arr, size);
				} else {
					printf("No data available. Please input data first.\n");
				}
				break;
			case 5: // Exit
				printf("Exiting program. Goodbye!\n");
				break;
			default:
				printf("Invalid choice. Please try again.\n");
		}
	} while (choice != 5);

	return 0;
}

// Function to input array data
void inputArray(int arr[], int *size) {
	int n;
	printf("Enter number of elements (1 to %d): ", MAX_SIZE);
	scanf("%d", &n);

	if (n < 1 || n > MAX_SIZE) {
		printf("Invalid size. Must be between 1 and %d.\n", MAX_SIZE);
		return;
	}

	*size = n;
	for (int i = 0; i < n; i++) {
		printf("Enter element %d: ", i + 1);
		scanf("%d", &arr[i]);
	}
	printf("Data input completed!\n");
}

// Function to display array
void displayArray(int arr[], int size) {
	printf("Array elements: ");
	for (int i = 0; i < size; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}

// Function to search for a value
int searchValue(int arr[], int size, int target) {
	for (int i = 0; i < size; i++) {
		if (arr[i] == target) {
			return i; // return index if found
		}
	}
	return -1; // not found
}

// Function to calculate statistics
void calculateStatistics(int arr[], int size) {
	int sum = 0, max = arr[0], min = arr[0];
	for (int i = 0; i < size; i++) {
		sum += arr[i];
		if (arr[i] > max) max = arr[i];
		if (arr[i] < min) min = arr[i];
	}
	double avg = (double)sum / size;

	printf("Sum = %d\n", sum);
	printf("Average = %.2f\n", avg);
	printf("Maximum = %d\n", max);
	printf("Minimum = %d\n", min);
}
