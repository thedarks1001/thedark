#include <stdio.h>
#define max_size 100 

void inputarray(int arr[], int *size);
void displayarray(int arr[] , int size);
int searchvalue(int arr[],int size,int target );
void caculatestatistics(int arr[], int size);

int main(){
	int arr[max_size], size = 0, target, index, choice;
	do{
	printf("---menu---\n");	
	printf("1. nhap data\n");	
	printf("2. hien  data\n");	
	printf("3. tim 1 so\n");	
	printf("4. tinh toan\n");	
	printf("5 exit\n");	
	scanf("%d", &choice);
	    switch(choice){
		    case 1:
		       inputarray(arr,&size);
		        break;
		    case 2:
			     if (size >0){
				     displayarray( arr,size);
			      } else {
				    	printf("khong co du lieu . vui long nhap du lieu truoc\n");
				} 
				break;
			
		    case 3:
		    if(size>0){
			    printf("nhap so muon tim \n");
			     scanf("%d",&target);
			     index = searchvalue(arr,size,target);
			    if (index == -1){
			   printf("so %d khong tim thay trong mang \n", target); 
		      }
		          else {
		    printf("tim thay so %d trong mang %d.\n",target, index );
			}
		}   else{
		      printf("khong co data . vui long nhap data truoc\n")	;
			} 
			break ;
		case 4:
		  if(size>0){
		  	caculatestatistics(arr,size);
		  }	
		     else {
		      printf("khong co data de tinh . vui long nhap data truoc\n");
	    }
		     break 	;
		case 5: 
		   printf("thoat chuong trinh\n");
		    break ;
		defaut:
			printf("chon khong hop le. vui long chon lai\n");
		}	
	} while(choice !=5)	;
	return 0;
			
}
void inputarray(int arr[],int *size){ int n;
    printf("Enter number of elements (1 to %d): ", max_size);
    scanf("%d", &n);

    if (n < 1 || n > max_size) {
        printf("Invalid size. Must be between 1 and %d.\n", max_size);
        return;
    }

    *size = n;
    for (int i = 0; i < n; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    printf("Data input completed!\n");
}




void displayarray(int arr[],int size){
	printf("Array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int searchvalue(int arr[],int size , int target){
	for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
            return i; // return index if found
        }
    }
    return -1; // not found
}

void caculatestatistics(int arr[],int size){
	int sum = 0, max = arr[0], min = arr[0];
    for (int i = 0; i < size; i++) {
        sum += arr[i];
        if (arr[i] > max) max = arr[i];
        if (arr[i] < min) min = arr[i];
    }
    double avg = (double)sum / size;

    printf("Sum = %d\n", sum);
    printf("Average = %.2f\n", avg);
    printf("Maximum = %d\n", max);
    printf("Minimum = %d\n", min);
}




