#include <stdio.h>

/*Bat dau
   |
Nhap a, b, c
   |
min = a
   |
Co b < min ?
   |---Co---> min = b
   |---Khong--> giu nguyen
   |
Co c < min ?
   |---Co---> min = c
   |---Khong--> giu nguyen
   |
In ra min
   |
Ket thuc
*/


int main() {
    int a, b, c, min;
    printf("Nhap a, b, c: ");
    scanf("%d %d %d", &a, &b, &c);

    min = a;                 
    if (b < min) min = b;   
    if (c < min) min = c;   

    printf("So nho nhat la: %d\n", min);

    return 0;
}
