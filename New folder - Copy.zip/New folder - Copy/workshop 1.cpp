#include <stdio.h>

int main() {
    int n;  // so luong hoc sinh
    float score, total = 0; 
    int pass = 0, fail = 0;

    // nhap so luong hoc sinh (kiem tra hop le)
    printf("Nhap so luong hoc sinh: ");
    scanf("%d", &n);

    while (n <= 0) {
        printf("Nhap sai! So hoc sinh phai > 0. Nhap lai: ");
        scanf("%d", &n);
    }

    // nhap diem tung hoc sinh
    for (int i = 1; i <= n; i++) {
        printf("Nhap diem hoc sinh %d (0-10) ", i);
        scanf("%f", &score);

        // kiem tra dihonem hop le
        while (score < 0 || score > 10) {
            printf("Diem kg hop le! Nhap lai (0-10): ");
            scanf("%f", &score);
        }

        // tinh toan tong diem 
        total += score;

        if (score >= 5)
            pass++;
        else
            fail++;
    }

    // in ket qua thong ke
    printf("\n===== Thong ke lop =====\n");
    printf("Tong diem ca lop: %.2f\n", total);
    printf("Diem trung binh: %.2f\n", total / n);
    printf("So hoc sinh dau: %d\n", pass);
    printf("So hoc sinh rot: %d\n", fail);

    return 0;
}
