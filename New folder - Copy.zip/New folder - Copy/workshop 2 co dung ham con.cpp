#include <stdio.h>

// Ham kiem tra dau vao
float inputValidation(const char*msg){
float value ; 
    do {
        printf("%s", msg);
        scanf("%f", &value);
        if (value < 0) {
            printf("Gia tri khong hop le! Vui long nhap lai.\n");
        }
    } while (value < 0);
    return value;
}

// Ham tinh phu cap
float calculateAllowance(float salary) {
    if (salary < 6000000)
        return salary * 0.25;
    else if (salary <= 15000000)
        return salary * 0.15;
    else
        return salary * 0.10;
}

// Ham tinh thue
float calculateTax(float totalIncome) {
    if (totalIncome <= 8000000)
        return 0;
    else
        return (totalIncome - 8000000) * 0.10;
}

// Ham tinh thu nhap thuc nhan
float calculateNetIncome(float salary) {
    float allowance = calculateAllowance(salary);
    float totalIncome = salary + allowance;
    float tax = calculateTax(totalIncome);
    return totalIncome - tax;
}

int main() {
    int n;
    float salary, allowance, totalIncome, tax, netIncome;
    float totalCompanyCost = 0;
    int count25 = 0, count15 = 0, count10 = 0;

    // Nhap so nhan vien
    n = (int)inputValidation("Nhap so nhan vien: ");
    while (n <= 0) {
        printf("So nhan vien phai > 0. Nhap lai!\n");
        n = (int)inputValidation("Nhap so nhan vien: ");
    }

    printf("\n===== CHI TIET LUONG NHAN VIEN =====\n");

    // Xu ly tung nhan vien
    for (int i = 1; i <= n; i++) {
        printf("\n--- Nhan vien %d ---\n", i);

        salary = inputValidation("Nhap luong co ban: ");
        allowance = calculateAllowance(salary);
        totalIncome = salary + allowance;
        tax = calculateTax(totalIncome);
        netIncome = totalIncome - tax;

        // In chi tiet nhan vien
        printf("Luong co ban: %.2f\n", salary);
        printf("Phu cap: %.2f\n", allowance);
        printf("Tong thu nhap: %.2f\n", totalIncome);
        printf("Thue: %.2f\n", tax);
        printf("Thu nhap thuc nhan: %.2f\n", netIncome);

        // Cap nhat thong ke cong ty
        totalCompanyCost += netIncome;

        if (salary < 6000000) count25++;
        else if (salary <= 15000000) count15++;
        else count10++;
    }

    // Thong ke cong ty
    printf("\n===== THONG KE CONG TY =====\n");
    printf("Tong chi phi luong: %.2f\n", totalCompanyCost);
    printf("So nhan vien phu cap 25%%: %d\n", count25);
    printf("So nhan vien phu cap 15%%: %d\n", count15);
    printf("So nhan vien phu cap 10%%: %d\n", count10);

    return 0;
}
