#include <stdio.h>

int main() {
    printf("hello word!\n");
    return 0;
}
