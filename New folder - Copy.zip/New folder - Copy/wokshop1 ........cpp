#include <stdio.h>

int main() {
    int n ; 
    float score , total =0 ; 
    int pass = 0 , fail = 0 ;

    printf("nhap so luong hoc sinh: ");
    scanf("%d",&n);

    while (n<=0){
       printf("nhap sai , nhap lai ");
       scanf("%d",&n);
    }

    for (int i =1;i<=n;i++){
        printf("nhap diem hoc sinh %d ",i)	;
        scanf("%f",&score );

        while (score < 0 || score > 10){
	      printf("nhap lai ");
	     scanf("%f",&score );
         }
         
	    total += score ;
	       if (score >=5 )
		   pass++;
	      else fail++;
     }
      printf("\n===== Thong ke lop =====\n");
    printf("Tong diem ca lop: %.2f\n", total);
    printf("Diem trung binh: %.2f\n", total / n);
    printf("So hoc sinh dau: %d\n", pass);
    printf("So hoc sinh rot: %d\n", fail);




return 0 ;
}
