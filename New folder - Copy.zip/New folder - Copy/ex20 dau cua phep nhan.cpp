#include <stdio.h>

int main() {
    int a, b;
    printf("Enter two integers (a b): ");
    scanf("%d %d", &a, &b);

    if (a == 0 || b == 0) {
        printf("Sign = 0\n");
    } else if ((a > 0 && b > 0) || (a < 0 && b < 0)) {
        printf("Sign = +1\n");
    } else {
        printf("Sign = -1\n");
    }

    return 0;
}

