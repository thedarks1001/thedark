#include <stdio.h>

int main() {
    int A, B, temp;

    printf("Enter A: ");
    scanf("%d", &A);
    printf("Enter B: ");
    scanf("%d", &B);

  
    temp = A;
    A = B;
    B = temp;

    printf("After switch: A = %d, B = %d\n", A, B);

    return 0;
}
