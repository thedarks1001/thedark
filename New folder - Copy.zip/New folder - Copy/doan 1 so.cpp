#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*Bat dau
   |
Tao so bi mat ngau nhien (1..50)
   |
Lap lai
   |
Nhap so doan
   |
So doan = so bi mat ?
   |---Co---> In "Doan dung" -> Ket thuc
   |---Khong-->
         |
         So doan > so bi mat ?
         |---Co---> In "So bi mat nho hon"
         |---Khong-> In "So bi mat lon hon"
         |
Quay lai lap
*/
int main() {
    int secret, guess;

    srand(time(NULL));              
    secret = rand() % 50 + 1;       

    printf("Doan mot so tu 1 den 50:\n");
    do {
        printf("Nhap so cua ban: ");
        scanf("%d", &guess);

        if (guess > secret) {
            printf("So bi mat nho hon so ban doan!\n");
        } else if (guess < secret) {
            printf("So bi mat lon hon so ban doan!\n");
        } else {
            printf("Chuc mung! Ban da doan dung so %d\n", secret);
        }
    } while (guess != secret);

    return 0;
}
