#include <stdio.h>
#define PI 3.141592653589793
#include <math.h>
int main() {
    double radius, area;
    printf("Enter radius of the disk: ");
    scanf("%lf", &radius);

    area = PI * radius * radius;
    printf("Surface of the disk = %.2lf\n", area);
    
double a, b;
    printf("Enter radius of the disk: ");
    scanf("%lf", &a);

    b = M_PI * a * a;  
    printf("Surface of the disk = %.2lf\n", b);
    return 0;
}
