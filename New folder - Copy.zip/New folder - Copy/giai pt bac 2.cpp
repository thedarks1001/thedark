#include <stdio.h>
#include <math.h>


/*
Thuat toan:

Nhap a, b, c.

Neu a == 0 → phương trình trở thành bậc 1: bx + c = 0.

Neu b == 0 và c == 0 → vô số nghiệm.

Neu b == 0 và c != 0 → vô nghiệm.

Ngược lại → nghiệm: x = -c/b.

Neu a != 0:

Tính delta = b^2 - 4ac.

Neu delta < 0 → phương trình vô nghiệm thực.

Nếu delta = 0 → phương trình có nghiệm kep:


Neu delta > 0 → phương trinh có 2 nghiem phan biet:
*/
int main() {
    double a, b, c;
    printf("Nhap a, b, c: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    if (a == 0) {
        // Phuong trinh bac 1: bx + c = 0
        if (b == 0) {
            if (c == 0) {
                printf("Phuong trinh co vo so nghiem\n");
            } else {
                printf("Phuong trinh vo nghiem\n");
            }
        } else {
            printf("Phuong trinh co 1 nghiem: x = %.2lf\n", -c / b);
        }
    } else {
        double delta = b*b - 4*a*c;

        if (delta < 0) {
            printf("Phuong trinh vo nghiem thuc\n");
        } else if (delta == 0) {
            double x = -b / (2*a);
            printf("Phuong trinh co nghiem kep: x = %.2lf\n", x);
        } else {
            double x1 = (-b + sqrt(delta)) / (2*a);
            double x2 = (-b - sqrt(delta)) / (2*a);
            printf("Phuong trinh co 2 nghiem phan biet:\n");
            printf("x1 = %.2lf\n", x1);
            printf("x2 = %.2lf\n", x2);
        }
    }

    return 0;
}
