#include <stdio.h>
#include <math.h>

/*Bat dau
   |
sum = 0, sumSquares = 0, count = 0
   |
Lap lai
   |
Nhap x
   |
x = 0 ?
   |---Co---> Thoat vong lap
   |---Khong-->
         |
         x < 1 hoac x > 9 ?
         |---Co---> Bo qua (khong lam gi)
         |---Khong-->
               |
               sum = sum + x
               sumSquares = sumSquares + x^2
               count = count + 1
   |
Quay lai lap
   |
count > 0 ?
   |---Co--->
        avg = sum / count
        rms = sqrt(sumSquares / count)
        In sum, avg, rms
   |---Khong---> In "Khong co gia tri hop le"
   |
Ket thuc
*/
int main() {
    int x, count = 0;
    double sum = 0, sumSquares = 0;

    printf("Nhap cac so nguyen (1-9), nhap 0 de thoat:\n");

    while (1) {
        scanf("%d", &x);
        if (x == 0) break;              
        if (x < 1 || x > 9) continue;   

        sum += x;
        sumSquares += x * x;
        count++;
    }

    if (count > 0) {
        double avg = sum / count;
        double rms = sqrt(sumSquares / count);

        printf("Tong = %.2lf\n", sum);
        printf("Trung binh cong = %.2lf\n", avg);
        printf("RMS = %.2lf\n", rms);
    } else {
        printf("Khong co gia tri hop le!\n");
    }

    return 0;
}
