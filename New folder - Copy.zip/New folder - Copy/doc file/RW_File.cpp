#include <stdio.h>
#include <stdlib.h>

// Compute sum
int sum(int arr[], int n) {
    int s = 0;
    for (int i = 0; i < n; i++) {
        s += arr[i];
    }
    return s;
}

// Compute average
float average(int arr[], int n) {
    int s = sum(arr, n);
    return (float)s / n;
}

// find max
int Max(int arr[], int n) {
    int m = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > m) {
            m = arr[i];
        }
    }
    return m;
}

// find min
int Min(int arr[], int n) {
    int m = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] < m) {
            m = arr[i];
        }
    }
    return m;
}

int main() {
    FILE *fin, *fout;
    int arr[1000]; // max size of array is 1000
    int n;

    // Open file input.txt to read data
    fin = fopen("input.txt", "r");
    if (fin == NULL) {
        printf("File input.txt is not opened\n");
        return 1;
    }

    // Read number elements of array
    fscanf(fin, "%d", &n);
    if (n <= 0 || n > 1000) {
        printf("Number elements of array is invalid.\n");
        fclose(fin);
        return 1;
    }

    // Read array
    for (int i = 0; i < n; i++) {
        fscanf(fin, "%d", &arr[i]);
    }
    fclose(fin);

    // Computing
    int s = sum(arr, n);
    float av = average(arr, n);
    int ma = Max(arr, n);
    int mi = Min(arr, n);

    // Write result to file output.txt
    fout = fopen("output1.txt", "w");
    if (fout == NULL) {
        printf("Can't open file output.txt\n");
        return 1;
    }

    fprintf(fout, "Sum: %d\n", s);
    fprintf(fout, "Average: %.2f\n", av);
    fprintf(fout, "Max: %d\n", ma);
    fprintf(fout, "Min: %d\n", mi);

    fclose(fout);

    printf("Results are writen to file output.txt\n");
    return 0;
}

