#include <stdio.h>

/*   Bat dau
      |
   Nhap X, Y
      |
   X = Y ?
   /     \
  Co      Khong
  |         |
 X XOR Y=0  X XOR Y=1
      |
    Xuat ket qua
      |
    Ket thuc

*/
int main() {
    int X, Y;
    printf("Nhap X (0 hoac 1): ");
    scanf("%d", &X);
    printf("Nhap Y (0 hoac 1): ");
    scanf("%d", &Y);

    int ketqua = (X || Y) && !(X && Y); // Cong thuc XOR
    printf("Ket qua X XOR Y = %d\n", ketqua);

    return 0;
}
