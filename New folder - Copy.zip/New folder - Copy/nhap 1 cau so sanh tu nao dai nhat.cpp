#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char cau[200];      // chuoi luu cau nhap vao
    char tu[50];        // tu hien tai
    int i = 0, j = 0;   
    int maxDoDai = 0;   // do dai lon nhat
    int dodai;          // do dai cua mot tu

    printf("Nhap mot cau: ");
    fgets(cau, sizeof(cau), stdin);

    // ---- Lan 1: tim do dai lon nhat ----
    while (1) {
        if (cau[i] == ' ' || cau[i] == '\n' || cau[i] == '\0' || ispunct(cau[i])) {
            if (j > 0) { 
                tu[j] = '\0';               // ket thuc chuoi tu
                dodai = strlen(tu);         // tinh do dai
                if (dodai > maxDoDai) {
                    maxDoDai = dodai;       // cap nhat do dai lon nhat
                }
                j = 0; // reset lai vi tri
            }
            if (cau[i] == '\0') break;      // neu het chuoi thi thoat
        } else {
            tu[j++] = cau[i];               // them ky tu vao tu
        }
        i++;
    }

    // ---- Lan 2: in tat ca cac tu co do dai = maxDoDai ----
    printf("Cac tu dai nhat (do dai %d):\n", maxDoDai);

    i = 0; j = 0;
    while (1) {
        if (cau[i] == ' ' || cau[i] == '\n' || cau[i] == '\0' || ispunct(cau[i])) {
            if (j > 0) {
                tu[j] = '\0';
                dodai = strlen(tu);
                if (dodai == maxDoDai) {
                    printf("%s\n", tu);
                }
                j = 0;
            }
            if (cau[i] == '\0') break;
        } else {
            tu[j++] = cau[i];
        }
        i++;
    }

    return 0;
}
