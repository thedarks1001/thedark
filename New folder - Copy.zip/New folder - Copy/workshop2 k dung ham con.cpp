#include <stdio.h>

int main() {
    int n, count25 = 0, count15 = 0, count10 = 0;
    float salary, allowance, totalIncome, tax, netIncome, totalCompanyCost = 0;

    // nhap so nhan vien
    do {
        printf("Nhap so nhan vien: ");
        scanf("%d", &n);
        if (n <= 0) printf("So nhan vien phai > 0. Nhap lai!\n");
    } while (n <= 0);

    // xu ly tung nhan vien
    for (int i = 1; i <= n; i++) {
        printf("\n--- Nhan vien %d ---\n", i);

        // nhap luong co ban
        do {
            printf("Nhap luong co ban: ");
            scanf("%f", &salary);
            if (salary <= 0) printf("Luong phai > 0. Nhap lai!\n");
        } while (salary <= 0);

        // tinh phu cap
        if (salary < 6000000) allowance = salary * 0.25;
        else if (salary <= 15000000) allowance = salary * 0.15;
        else allowance = salary * 0.10;

        // tong thu nhap
        totalIncome = salary + allowance;

        // tinh thue
        if (totalIncome <= 8000000) tax = 0;
        else tax = (totalIncome - 8000000) * 0.10;

        // thu nhap thuc nhan
        netIncome = totalIncome - tax;

        // in thong tin nhan vien
        printf("Luong: %.2f, Phu cap: %.2f, Tong: %.2f, Thue: %.2f, Thuc nhan: %.2f\n",
               salary, allowance, totalIncome, tax, netIncome);

        // cap nhat thong ke
        totalCompanyCost += netIncome;
        if (salary < 6000000) count25++;
        else if (salary <= 15000000) count15++;
        else count10++;
    }

    // thong ke cong ty
    printf("\n===== THONG KE =====\n");
    printf("Tong chi phi: %.2f\n", totalCompanyCost);
    printf("Nhan vien phu cap 25%%: %d\n", count25);
    printf("Nhan vien phu cap 15%%: %d\n", count15);
    printf("Nhan vien phu cap 10%%: %d\n", count10);

    return 0;
}
