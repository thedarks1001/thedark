#include <stdio.h>

int main() {
    long long num;
    int digit, place = 1;

    printf("Enter a large integer: ");
    scanf("%lld", &num);

    printf("\nDigits by place value:\n");

    while (num > 0) {
        digit = num % 10;
        printf("Place %d: %d\n", place, digit);
        num /= 10;
        place *= 10;
    }

    return 0;
}
