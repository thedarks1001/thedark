#include <stdio.h>
#define MAX_SIZE 100

int main() {
    int arr[MAX_SIZE], size = 0, target, index, choice;

    // Vong lap menu
    do {
        // Hien thi menu
        printf("\n--- MENU ---\n");
        printf("1. Nhap du lieu\n");
        printf("2. Hien thi mang\n");
        printf("3. Tim kiem mot so\n");
        printf("4. Thong ke (Tong, Trung binh, Lon nhat, Nho nhat)\n");
        printf("5. Thoat\n");
        printf("Nhap lua chon: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1: {
                // Nhap du lieu
                int n;
                printf("Nhap so luong phan tu (1 den %d): ", MAX_SIZE);
                scanf("%d", &n);

                if (n < 1 || n > MAX_SIZE) {
                    printf("So luong khong hop le. Phai tu 1 den %d.\n", MAX_SIZE);
                    break;
                }

                size = n;
                for (int i = 0; i < n; i++) {
                    printf("Nhap phan tu %d: ", i + 1);
                    scanf("%d", &arr[i]);
                }
                printf("Da nhap du lieu xong!\n");
                break;
            }

            case 2: {
                // Hien thi mang
                if (size > 0) {
                    printf("Mang gom cac phan tu: ");
                    for (int i = 0; i < size; i++) {
                        printf("%d ", arr[i]);
                    }
                    printf("\n");
                } else {
                    printf("Chua co du lieu. Vui long nhap truoc.\n");
                }
                break;
            }

            case 3: {
                // Tim kiem
                if (size > 0) {
                    printf("Nhap so can tim: ");
                    scanf("%d", &target);
                    index = -1;
                    for (int i = 0; i < size; i++) {
                        if (arr[i] == target) {
                            index = i;
                            break;
                        }
                    }
                    if (index != -1) {
                        printf("Tim thay gia tri %d tai vi tri %d.\n", target, index);
                    } else {
                        printf("Khong tim thay gia tri %d trong mang.\n", target);
                    }
                } else {
                    printf("Chua co du lieu. Vui long nhap truoc.\n");
                }
                break;
            }

            case 4: {
                // Thong ke
                if (size > 0) {
                    int sum = 0, max = arr[0], min = arr[0];
                    for (int i = 0; i < size; i++) {
                        sum += arr[i];
                        if (arr[i] > max) max = arr[i];
                        if (arr[i] < min) min = arr[i];
                    }
                    double avg = (double)sum / size;

                    printf("Tong = %d\n", sum);
                    printf("Trung binh = %.2f\n", avg);
                    printf("Lon nhat = %d\n", max);
                    printf("Nho nhat = %d\n", min);
                } else {
                    printf("Chua co du lieu. Vui long nhap truoc.\n");
                }
                break;
            }

            case 5:
                printf("Thoat chuong trinh. Tam biet!\n");
                break;

            default:
                printf("Lua chon khong hop le. Vui long nhap lai.\n");
        }
    } while (choice != 5);

    return 0;
}
