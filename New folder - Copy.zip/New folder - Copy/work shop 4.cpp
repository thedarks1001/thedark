#include <stdio.h>
#include <stdlib.h>

// Constants
#define MAX_DAYS 100


// Struct definition
typedef struct {
    int sales[MAX_DAYS];
    int count;
} SalesData;

// Function prototypes
SalesData inputSales();
void displaySales(SalesData data);
void sortAscending(SalesData data);
void sortDescending(SalesData data);
void searchGreaterThan(SalesData data, int target);

int main() {
    SalesData data;
    int choice, target;
    int hasData = 0; // 

    do {
        printf("\n=== Enhanced Sales Data Management Menu ===\n");
        printf("1. Input Sales Data\n");
        printf("2. Display Sales Data\n");
        printf("3. Sort Sales Data in Ascending Order\n");
        printf("4. Sort Sales Data in Descending Order\n");
        printf("5. Search for Sales Greater Than a Target\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                data = inputSales();
                hasData = 1;
                break;
            case 2:
                if (hasData) displaySales(data);
                else printf("Please input sales data first!\n");
                break;
            case 3:
                if (hasData) sortAscending(data);
                else printf("Please input sales data first!\n");
                break;
            case 4:
                if (hasData) sortDescending(data);
                else printf("Please input sales data first!\n");
                break;
            case 5:
                if (hasData) {
                    printf("Enter target: ");
                    scanf("%d", &target);
                    searchGreaterThan(data, target);
                } else {
                    printf("Please input sales data first!\n");
                }
                break;
            case 6:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 6);

    return 0;
}

// Function implementations

SalesData inputSales() {
    SalesData data;
    do {
        printf("Enter number of days (1 - %d): ", MAX_DAYS);
        scanf("%d", &data.count);
    } while (data.count < 1 || data.count > MAX_DAYS);

    for (int i = 0; i < data.count; i++) {
        printf("Day %d sales: ", i + 1);
        scanf("%d", &data.sales[i]);
    }
    return data;
}

void displaySales(SalesData data) {
    printf("\n--- Sales Data ---\n");
    for (int i = 0; i < data.count; i++) {
        printf("Day %d: %d\n", i + 1, data.sales[i]);
    }
}

void sortAscending(SalesData data) {
    for (int i = 0; i < data.count - 1; i++) {
        for (int j = i + 1; j < data.count; j++) {
            if (data.sales[i] > data.sales[j]) {
                int temp = data.sales[i];
                data.sales[i] = data.sales[j];
                data.sales[j] = temp;
            }
        }
    }
    printf("\n--- Sales Data Ascending ---\n");
    for (int i = 0; i < data.count; i++) {
        printf("%d ", data.sales[i]);
    }
    printf("\n");
}

void sortDescending(SalesData data) {
    for (int i = 0; i < data.count - 1; i++) {
        for (int j = i + 1; j < data.count; j++) {
            if (data.sales[i] < data.sales[j]) {
                int temp = data.sales[i];
                data.sales[i] = data.sales[j];
                data.sales[j] = temp;
            }
        }
    }
    printf("\n--- Sales Data Descending ---\n");
    for (int i = 0; i < data.count; i++) {
        printf("%d ", data.sales[i]);
    }
    printf("\n");
}

void searchGreaterThan(SalesData data, int target) {
    int found = 0;
    printf("\n--- Sales Greater Than %d ---\n", target);
    for (int i = 0; i < data.count; i++) {
        if (data.sales[i] > target) {
            printf("Day %d: %d\n", i + 1, data.sales[i]);
            found = 1;
        }
    }
    if (!found) {
        printf("No sales greater than %d found.\n", target);
    }
}
