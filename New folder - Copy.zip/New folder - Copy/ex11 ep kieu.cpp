#include <stdio.h>

int main() {
    int a = 5, b = 2;
    int result1;
    float result2;


    result1 = a / b; 
    printf("Without cast: %d / %d = %d\n", a, b, result1);

 
    result2 = (float)a / b;  
    printf("With cast: %d / %d = %.2f\n", a, b, result2);

    return 0;
}
