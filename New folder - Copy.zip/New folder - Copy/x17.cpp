#include <stdio.h>

int main() {
    int a, b, c;
    printf("Enter two integers (a b): ");
    scanf("%d %d", &a, &b);

    c = a ^ b; // XOR
    printf("%d XOR %d = %d\n", a, b, c);

    return 0;
}
