#include <stdio.h>

int main() {
    int a, b, c, x, y;
    printf("Enter coefficients a, b, c and value x: ");
    scanf("%d %d %d %d", &a, &b, &c, &x);

    y = a*x*x + b*x + c;
    printf("f(x) = %d\n", y);

    return 0;
}
