#include <stdio.h>

int main() {
    int a, b, c, d, sum;
    printf("Enter 4 integers: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);

    sum = a + b + c + d;
    printf("Sum = %d\n", sum);


   

    int num1, sum1 = 0;
    for(int i = 0; i < 4; i++) {
        printf("Enter number %d: ", i+1);
        scanf("%d", &num1);
        sum1 += num1;
    }
    printf("Sum = %d\n", sum1);
    return 0;
}


