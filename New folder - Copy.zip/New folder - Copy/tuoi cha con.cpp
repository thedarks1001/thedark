#include <stdio.h>

/*   Bat dau
      |
   Nhap tuoi cha, tuoi con
      |
   Nam = 0
      |
  Lap lai:
   tuoi cha + Nam == 2 * (tuoi con + Nam) ?
        |
      Co -> In ra Nam -> Ket thuc
      Khong -> Nam = Nam + 1 -> Lap lai
*/

int main() {
    int cha, con;
    printf("Nhap tuoi cha: ");
    scanf("%d", &cha);
    printf("Nhap tuoi con: ");
    scanf("%d", &con);

    int nam = 0;
    while (1) {
        if (cha + nam == 2 * (con + nam)) {
            printf("So nam de tuoi cha gap doi tuoi con: %d\n", nam);
            break;
        }
        nam++;
    }

    return 0;
}
